#include <stdio.h>
#include <stdlib.h>

#define MAXSIZE 20
typedef double ElemType;
typedef struct list {
  ElemType a[MAXSIZE + 1];
  int len;
} SeqList;

SeqList * InitList();
void InitList2(SeqList **ppList);
int ListFull(SeqList *pList);
int ListEmpty(SeqList *pList);
int ListLen(SeqList *pList);
void Error(char *msg);
int GetElem(SeqList *pList, int i, ElemType *pElm);
int InsertElem(SeqList * pList, int i, ElemType elm);
int DelElem(SeqList *pList, int i, ElemType *pElm);
void PrintList(SeqList *pList);


int main() {
  int i, j, k;
  SeqList *A, *B, *C;
  // ElemType a[M+1] = {0, 0, 7,0,3,1,9,8,5,17,-8,100}, b[N+1] = {0, 0, 8,1,22,7,-9, 8}, x;

  
  return 0;
}

SeqList * InitList() {
  SeqList *pList;
  pList = (SeqList *)malloc(sizeof(SeqList));
  pList->len = 0;
  return pList;
}
void InitList2(SeqList **ppList) {
  *ppList = (SeqList *)malloc(sizeof(SeqList));
  (*ppList)->len = 0;
}
int ListFull(SeqList *pList) {
  /*
  if (pList->len == MAXSIZE)
    return 1;
  else
    return 0;
  */
  return (pList->len == MAXSIZE) ? 1 : 0;
}
int ListEmpty(SeqList *pList) {
  return (pList->len == 0) ? 1 : 0;
}
int ListLen(SeqList *pList) {
  return pList->len;
}
void Error(char *msg) {
  printf("error: %s\n", msg);
}
int GetElem(SeqList *pList, int i, ElemType *pElm) {
  if (ListEmpty(pList)) {
    Error("Get element from empty list");
    return 0;
  }
  if (i < 1 || i > MAXSIZE) {
    Error("Get element from illegal position!");
    return 0;
  }
  *pElm = pList->a[i];
  return 1;
}

int InsertElem(SeqList * pList, int i, ElemType elm) {
  int k;
  if (ListFull(pList)) {
    Error("Insert element to a full list!");
    return 0;
  }
  if (i < 1 || i > pList->len + 1) {
    Error("insert element out of range!");
    return 0;
  }
  for (k = pList->len; k >= i; k--) pList->a[k + 1] = pList->a[k];
  pList->a[i] = elm;
  pList->len += 1;
  return 1;
}

int DelElem(SeqList *pList, int i, ElemType *pElm) {
  if (ListEmpty(pList)) {
    Error("delete element from an empty list");
    return 0;
  }
  if (i < 1 || i > pList->len) {
    Error("delete element out of range");
    return 0;
  }
  *pElm = pList->a[i];
  pList->len -= 1;
  return 1;
}

void PrintList(SeqList *pList) {
  int i;
  for (i = 1; i <= pList->len; i++)
    printf("%.2lf ", pList->a[i]);
  putchar('\n');
}
